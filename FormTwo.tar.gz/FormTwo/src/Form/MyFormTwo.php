<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Drupal\FormTwo\Form;


use Drupal\Core\Url;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\CssCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class MyFormTwo extends FormBase{
  public function getFormId() {
    return 'FormTwo';
  }
  public function buildForm(array $form, FormStateInterface $form_state) {
    
    $form['name'] = array(
      '#type' => 'fieldset',
      '#title' => $this->t('This is FieldSet'),
    );
    
    $form['mydate'] = [
      '#type' => 'date',
      '#title' => $this->t('Select Date'),
      '#attributes' => ['id'=>'mydate'],
      '#ajax' => [
        'callback' => '::MyDateAjax',
         'event' => 'oninput',
      ],
      '#suffix' => '<span id="datemsg"></span>',
    ];
    
    $form['dropbuttonlist'] = [
      '#type' => 'dropbutton',
      '#title' => $this->t('Link List'),
      '#links' => [
        'a' => [
          'title' => $this->t('First'), 
          'url' =>  Url::fromRoute('FormTwo.Form'),
        ],
        'b' => [
           'title' => $this->t('Second'), 
           'url' =>  Url::fromRoute('FormTwo.Form'),
        ],
      ],
    ];
    
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#ajax' => [
          'callback' => '::MyEmailAjax',
          'event' => 'change',
      ],
      '#suffix' => '<span id="emailmsg"></span>',
    ];
    $form['fileupload']=[
      '#type' => 'file',
      '#size' => 60,
      '#multiple' => TRUE,
      '#ajax' => [
          'callback' => '::MyfileAjax',
          'event' => 'change',
      ],
      '#suffix' => '<span id="emailmsg"></span>',
    ];
    return $form;
  }
    
    function MyEmailAjax($form, FormStateInterface $form_state) {
      $email=$form_state->getValue('email');
      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email format"; 
      }
      $ajax_response = new AjaxResponse();
      $ajax_response->addCommand(new HtmlCommand('#emailmsg', $emailErr));
      return $ajax_response;
    }
    //ajax is not working with date
    function MyDateAjax($form, FormStateInterface $form_state) {
      $mydate=$form_state->getValue('mydate');
      $ajax_response = new AjaxResponse();
      $ajax_response->addCommand(new CssCommand('#datemsg', $mydate));
      return $ajax_response;
    }
    function MyfileAjax($form, FormStateInterface $form_state){
      $myfile=$form_state->getValue('fileupload');
    }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    //nothing
  }

}
